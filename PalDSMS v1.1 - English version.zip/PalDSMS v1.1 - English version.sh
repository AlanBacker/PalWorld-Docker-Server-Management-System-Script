#!/bin/bash

# The directory where the script is currently located.
SCRIPT_DIR=$(dirname "$(realpath "$0")")
BACKUP_DIR="/var/lib/docker/volumes/palworld_saved/_data" # Make sure the path is correct
BACKUP_STORE="$SCRIPT_DIR/autobackups"
MCRCON_PATH="$SCRIPT_DIR/mcrcon"
MCRCON_PWD="" # Will be set when the script is run
BACKUP_FREQUENCY=1 # Back up every 1 hour
RESTART_FREQUENCY=4 # 每4小时重启一次

# Restart every 4 hours
mkdir -p "$BACKUP_STORE"

# Menu options
show_menu() {
    echo "----PalWorld Docker Server Management System v1.1 created by AlanBacker Bilibili:艾伦巴克----"
    echo "1. Install Docker"
    echo "2. Deploy a new Palworld server"
    echo "3. Deploy auto-maintenance system(You must first execute option 8 and set the AdminPassword and RCONenabled parameters before you can effectively execute this option!!!)"
    echo "4. Create a manual backup(You must first execute option 8 and set the AdminPassword and RCONenabled parameters before you can effectively execute this option!!!)"
    echo "5. Copy the backups from the manual backup file(manualbackup.zip)"
    echo "6. Copy the backups from the auto backup system"
    echo "7. Purge auto-maintenance system"
    echo "8. View real-time logs"
    echo "9. Edit game rules file"
    echo "10. Start the game Docker image"
    echo "11. Stop the game Docker image"
    echo "12. Restart the game Docker image"
    echo "13. RCON Broadcast Message"
    echo "14. Exit"
    echo "Please enter your choice:"
}

# Option 1 - Install Docker
install_docker() {
    # Install Docker
    apt-get update
    apt-get install -y ca-certificates curl gnupg lsb-release zip
    mkdir -p /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/debian/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian \
      $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
    apt-get update
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
    systemctl start docker
    systemctl enable docker
    echo "Docker installed successfully."
}

# Option 2 - Deploy a new Palworld server
deploy_palworld_server() {
    docker volume create palworld_saved
    docker pull kagurazakanyaa/palworld
    docker run -d --restart=always -e "ENABLE_MULTITHREAD=true" --name=palworld-server -v "palworld_saved:/opt/palworld/Pal/Saved" -p 8211:8211/udp -p 25575:25575 kagurazakanyaa/palworld
    echo "Palworld server deployed."
}

# Option 3 - Deploy Auto Maintenance System
deploy_auto_maintenance() {
    echo "Please enter the RCON password (for auto maintenance)"
    read -r MCRCON_PWD

    apt update && apt install zip -y

    # Create backup script
    cat <<EOF > "$SCRIPT_DIR/backup_script.sh"
#!/bin/bash
$MCRCON_PATH -p $MCRCON_PWD "save"
sleep 20
zip -r "${BACKUP_STORE}/backup-\$(date +\%Y-\%m-\%d-\%H%M).zip" "$BACKUP_DIR"
$MCRCON_PATH -p $MCRCON_PWD "Broadcast ServerBackupCompleted"
# If the backup folder exceeds 1GB, the oldest backup file in the folder will be automatically deleted.
total_size=\$(du -c "$BACKUP_STORE" | grep total\$ | awk '{print \$1}')
if [ \$total_size -ge 1048576 ]; then
    oldest_backup=\$(ls -t "$BACKUP_STORE" | tail -1)
    rm -f "$BACKUP_STORE/\$oldest_backup"
    $MCRCON_PATH -p $MCRCON_PWD "Broadcast Oldest backup deleted to free space"
fi
EOF
    chmod +x "$SCRIPT_DIR/backup_script.sh"

    # Perform a backup immediately
    "$SCRIPT_DIR/backup_script.sh"

    # Create restart script
    cat <<EOF > "$SCRIPT_DIR/restart_script.sh"
#!/bin/bash
$MCRCON_PATH -p $MCRCON_PWD "Broadcast ServerWillBeRestartIn5Mins"
sleep 300
docker restart palworld-server
EOF

    # Create auto update check script
    cat <<EOF > "$SCRIPT_DIR/update_check_script.sh"
#!/bin/bash
# Check for available updates
if docker pull kagurazakanyaa/palworld | grep -q 'Downloaded newer image'; then
    $MCRCON_PATH -p $MCRCON_PWD "Broadcast ServerWillBeRestartIn5Mins"
    sleep 300
    docker restart palworld-server
fi
EOF
    chmod +x "$SCRIPT_DIR/update_check_script.sh"

    # Set up cron jobs
    (crontab -l 2>/dev/null; echo "0 */$BACKUP_FREQUENCY * * * $SCRIPT_DIR/backup_script.sh") | crontab -
    (crontab -l 2>/dev/null; echo "5 */$RESTART_FREQUENCY * * * $SCRIPT_DIR/restart_script.sh") | crontab -
    (crontab -l 2>/dev/null; echo "*/30 * * * * $SCRIPT_DIR/update_check_script.sh") | crontab -
    echo "Auto maintenance system successfully deployed."
}

# Option 4 - Create a manual backup
create_backup() {
    echo "Please enter the RCON password (for manual backup)"
    read -r MCRCON_PWD
    echo "Creating manual backup..."
    $MCRCON_PATH -p $MCRCON_PWD "save"
    sleep 20
    apt update && apt install zip -y
    local backup_file="$SCRIPT_DIR/manualbackup.zip"
    zip -r "$backup_file" "$BACKUP_DIR"
    $MCRCON_PATH -p $MCRCON_PWD "Broadcast ServerBackupCompleted"
    echo "Manual backup created at $backup_file."
}

# Option 5 - Copy backup from backup file
copy_backup_from_folder() {
    echo "Copying backup from backup folder..."
    docker stop palworld-server
    sleep 20
    apt update && apt install zip -y
    local backup_file="$SCRIPT_DIR/scriptbackup.zip"
    unzip -o "$backup_file" -d "$BACKUP_DIR"
    docker start palworld-server
    echo "Backup restored from $backup_file."
}

# Option 6 - Copy backup from automated backup system
copy_backup_from_auto_system() {
    echo "Copying backup from auto backup system..."
    docker stop palworld-server
    sleep 20
    apt update && apt install zip -y
    echo "Available backups:"
    ls "$BACKUP_STORE"
    echo "Enter the name of the backup file to restore:"
    read -r backup_file
    unzip -o "$BACKUP_STORE$backup_file" -d "$BACKUP_DIR"
    docker start palworld-server
    echo "Backup $backup_file restored."
}

# Option 7 - Disable automatic maintenance system
purge_auto_maintenance() {
    crontab -l | grep -v "$SCRIPT_DIR/backup_script.sh" | crontab -
    crontab -l | grep -v "$SCRIPT_DIR/restart_script.sh" | crontab -
    echo "Auto-maintenance system purged."
}

# Option 8 - Check live logs
view_real_time_logs() {
    sudo docker logs palworld-server -f --tail=100
}

# Option 9 - Modify Game Rules File
edit_game_rules_file() {
    sudo nano /var/lib/docker/volumes/palworld_saved/_data/Config/LinuxServer/PalWorldSettings.ini
}

# Option 10 - Start the Pal Server
start_game_docker_image() {
    sudo docker start palworld-server
}

# Option 11 - Shut down the Pal server
stop_game_docker_image() {
    sudo docker stop palworld-server
}

# Option 12 - Restart the Pal server
restart_game_docker_image() {
    sudo docker restart palworld-server
}

# Option 13 - Remote RCON Server Command
rcon_broadcast_message() {
    if [ -z "$MCRCON_PWD" ]; then
        echo "Enter mcrcon password:"
        read -r MCRCON_PWD
    fi

    echo "Enter the command to broadcast:"
    read -r command
    $MCRCON_PATH -p "$MCRCON_PWD" "$command"
}

# Main loop
while true; do
    show_menu
    read -r choice
    case $choice in
        1) install_docker ;;
        2) deploy_palworld_server ;;
        3) deploy_auto_maintenance ;;
        4) create_backup ;;
        5) copy_backup_from_folder ;;
        6) copy_backup_from_auto_system ;;
        7) purge_auto_maintenance ;;
        8) view_real_time_logs ;;
        9) edit_game_rules_file ;;
        10) start_game_docker_image ;;
        11) stop_game_docker_image ;;
        12) restart_game_docker_image ;;
        13) rcon_broadcast_message ;;
        14) exit 0 ;;
        *) echo "Invalid choice, please try again." ;;
    esac
done

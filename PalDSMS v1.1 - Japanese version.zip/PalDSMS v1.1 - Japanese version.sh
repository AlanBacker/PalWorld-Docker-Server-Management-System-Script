#!/bin/bash

# スクリプトの現在のディレクトリ
SCRIPT_DIR=$(dirname "$(realpath "$0")")
BACKUP_DIR="/var/lib/docker/volumes/palworld_saved/_data" # パスが正しいことを確認してください
BACKUP_STORE="$SCRIPT_DIR/autobackups"
MCRCON_PATH="$SCRIPT_DIR/mcrcon"
MCRCON_PWD="" # スクリプト実行時に設定されます
BACKUP_FREQUENCY=1 # 1時間ごとにバックアップ
RESTART_FREQUENCY=4 # 4時間ごとに再起動

# 必要なディレクトリを作成
mkdir -p "$BACKUP_STORE"

# メニューオプション
show_menu() {
    echo "----Pal Dockerサーバー管理システム v1.1 by AlanBacker 哔哩哔哩：艾伦巴克----"
    echo "1. Dockerコンポーネントをインストール"
    echo "2. 新しいPalサーバーを展開"
    echo "3. 自動メンテナンスシステムを展開（オプション8を先に実行し、AdminPasswordとRCONEnabledパラメータを設定してください!!!）"
    echo "4. 手動バックアップを作成（オプション8を先に実行し、AdminPasswordとRCONEnabledパラメータを設定してください!!!）"
    echo "5. 手動バックアップファイルからサーバーデータを復元（ファイル名：manualbackup.zip）"
    echo "6. 自動バックアップシステムからサーバーデータを復元"
    echo "7. 自動メンテナンスシステムを解除"
    echo "8. ゲームサーバーのリアルタイムログを確認"
    echo "9. ゲームルールファイルを編集"
    echo "10. Pal Dockerイメージを起動"
    echo "11. Pal Dockerイメージを停止"
    echo "12. Pal Dockerイメージを再起動"
    echo "13. RCONを通じてサーバー命令を送信"
    echo "14. スクリプトを終了"
    echo "選択肢を入力してください:"
}

# オプション1 - Dockerのインストール
install_docker() {
    # Dockerのインストール
    apt-get update
    apt-get install -y ca-certificates curl gnupg lsb-release zip
    mkdir -p /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/debian/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian \
      $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
    apt-get update
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
    systemctl start docker
    systemctl enable docker
    echo "Dockerコンポーネントのインストールが成功しました。"
}

# オプション2 - 新しいPalworldサーバーの展開
deploy_palworld_server() {
    docker volume create palworld_saved
    docker pull kagurazakanyaa/palworld
    docker run -d --restart=always -e "ENABLE_MULTITHREAD=true" --name=palworld-server -v "palworld_saved:/opt/palworld/Pal/Saved" -p 8211:8211/udp -p 25575:25575 kagurazakanyaa/palworld
    echo "Palサーバーが展開されました。"
}

# オプション3 - 自動メンテナンスシステムの展開
deploy_auto_maintenance() {
    echo "RCONパスワードを入力してください（自動メンテナンス用）："
    read -r MCRCON_PWD

    apt update && apt install zip -y

    # バックアップスクリプトを作成
    cat <<EOF > "$SCRIPT_DIR/backup_script.sh"
#!/bin/bash
$MCRCON_PATH -p $MCRCON_PWD "save"
sleep 20
zip -r "${BACKUP_STORE}/backup-\$(date +\%Y-\%m-\%d-\%H%M).zip" "$BACKUP_DIR"
$MCRCON_PATH -p $MCRCON_PWD "Broadcast ServerBackupCompleted"
# バックアップフォルダの容量が1GBを超えた場合、最も古いバックアップファイルを自動的に削除します。
total_size=\$(du -c "$BACKUP_STORE" | grep total\$ | awk '{print \$1}')
if [ \$total_size -ge 1048576 ]; then
    oldest_backup=\$(ls -t "$BACKUP_STORE" | tail -1)
    rm -f "$BACKUP_STORE/\$oldest_backup"
    $MCRCON_PATH -p $MCRCON_PWD "Broadcast Oldest backup deleted to free space"
fi
EOF
    chmod +x "$SCRIPT_DIR/backup_script.sh"

    # すぐにバックアップを実行
    "$SCRIPT_DIR/backup_script.sh"

    # 再起動スクリプトを作成
    cat <<EOF > "$SCRIPT_DIR/restart_script.sh"
#!/bin/bash
$MCRCON_PATH -p $MCRCON_PWD "Broadcast ServerWillBeRestartIn5Mins"
sleep 300
docker restart palworld-server
EOF

    # 自動アップデートチェックスクリプトを作成
    cat <<EOF > "$SCRIPT_DIR/update_check_script.sh"
#!/bin/bash
# 利用可能なアップデートをチェック
if docker pull kagurazakanyaa/palworld | grep -q 'Downloaded newer image'; then
    $MCRCON_PATH -p $MCRCON_PWD "Broadcast ServerWillBeRestartIn5Mins"
    sleep 300
    docker restart palworld-server
fi
EOF
    chmod +x "$SCRIPT_DIR/update_check_script.sh"

    # cronジョブを設定
    (crontab -l 2>/dev/null; echo "0 */$BACKUP_FREQUENCY * * * $SCRIPT_DIR/backup_script.sh") | crontab -
    (crontab -l 2>/dev/null; echo "5 */$RESTART_FREQUENCY * * * $SCRIPT_DIR/restart_script.sh") | crontab -
    (crontab -l 2>/dev/null; echo "*/30 * * * * $SCRIPT_DIR/update_check_script.sh") | crontab -
    echo "自動メンテナンスシステムが展開されました。"
}

# オプション4 - 手動バックアップの作成
create_backup() {
    echo "RCONパスワードを入力してください（手動バックアップ用）："
    read -r MCRCON_PWD
    echo "手動バックアップを作成しています。"
    $MCRCON_PATH -p $MCRCON_PWD "save"
    sleep 20
    apt update && apt install zip -y
    local backup_file="$SCRIPT_DIR/manualbackup.zip"
    zip -r "$backup_file" "$BACKUP_DIR"
    $MCRCON_PATH -p $MCRCON_PWD "Broadcast ServerBackupCompleted"
    echo "手動バックアップが $backup_file に保存されました。"
}

# オプション5 - バックアップファイルからのデータ復元
copy_backup_from_folder() {
    echo "バックアップファイルからデータを復元しています..."
    docker stop palworld-server
    sleep 20
    apt update && apt install zip -y
    local backup_file="$SCRIPT_DIR/scriptbackup.zip"
    unzip -o "$backup_file" -d "$BACKUP_DIR"
    docker start palworld-server
    echo "$backup_file からのデータ復元が完了しました。"
}

# オプション6 - 自動バックアップシステムからのデータ復元
copy_backup_from_auto_system() {
    echo "自動バックアップシステムからデータを復元しています..."
    docker stop palworld-server
    sleep 20
    apt update && apt install zip -y
    echo "利用可能な自動バックアップ："
    ls "$BACKUP_STORE"
    echo "復元したいバックアップファイル名を入力してください："
    read -r backup_file
    unzip -o "$BACKUP_STORE$backup_file" -d "$BACKUP_DIR"
    docker start palworld-server
    echo "バックアップ $backup_file からのデータ復元が完了しました。"
}

# オプション7 - 自動メンテナンスシステムの解除
purge_auto_maintenance() {
    crontab -l | grep -v "$SCRIPT_DIR/backup_script.sh" | crontab -
    crontab -l | grep -v "$SCRIPT_DIR/restart_script.sh" | crontab -
    echo "自動メンテナンスシステムが解除されました。"
}

# オプション8 - リアルタイムログの確認
view_real_time_logs() {
    sudo docker logs palworld-server -f --tail=100
}

# オプション9 - ゲームルールファイルの編集
edit_game_rules_file() {
    sudo nano /var/lib/docker/volumes/palworld_saved/_data/Config/LinuxServer/PalWorldSettings.ini
}

# オプション10 - Palサーバーの起動
start_game_docker_image() {
    sudo docker start palworld-server
}

# オプション11 - Palサーバーの停止
stop_game_docker_image() {
    sudo docker stop palworld-server
}

# オプション12 - Palサーバーの再起動
restart_game_docker_image() {
    sudo docker restart palworld-server
}

# オプション13 - RCONを通じたサーバー命令の送信
rcon_broadcast_message() {
    if [ -z "$MCRCON_PWD" ]; then
        echo "RCONパスワードを入力してください："
        read -r MCRCON_PWD
    fi

    echo "送信したい命令を入力してください："
    read -r command
    $MCRCON_PATH -p "$MCRCON_PWD" "$command"
}

# メインループ
while true; do
    show_menu
    read -r choice
    case $choice in
        1) install_docker ;;
        2) deploy_palworld_server ;;
        3) deploy_auto_maintenance ;;
        4) create_backup ;;
        5) copy_backup_from_folder ;;
        6) copy_backup_from_auto_system ;;
        7) purge_auto_maintenance ;;
        8) view_real_time_logs ;;
        9) edit_game_rules_file ;;
        10) start_game_docker_image ;;
        11) stop_game_docker_image ;;
        12) restart_game_docker_image ;;
        13) rcon_broadcast_message ;;
        14) exit 0 ;;
        *) echo "不正な選択です。再入力してください。" ;;
    esac
done

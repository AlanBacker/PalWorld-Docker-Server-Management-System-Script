#!/bin/bash

# 脚本当前所在目录
SCRIPT_DIR=$(dirname "$(realpath "$0")")
BACKUP_DIR="/var/lib/docker/volumes/palworld_saved/_data" # 确保路径正确
BACKUP_STORE="$SCRIPT_DIR/autobackups"
MCRCON_PATH="$SCRIPT_DIR/mcrcon"
MCRCON_PWD="" # 会在脚本运行时设置
BACKUP_FREQUENCY=1 # 每1小时备份一次
RESTART_FREQUENCY=4 # 每4小时重启一次

# 创建所需目录
mkdir -p "$BACKUP_STORE"

# 菜单选项
show_menu() {
    echo "----幻兽帕鲁Docker服务器管理系统 v1.1 created by AlanBacker 哔哩哔哩:艾伦巴克----"
    echo "1. 安装Docker组件"
    echo "2. 部署一个全新的幻兽帕鲁服务器"
    echo "3. 部署自动维护系统(您必须先执行选项8，设置AdminPassword以及RCONEnabled参数后才可以有效执行这个选项!!!)"
    echo "4. 创建一个手动备份(您必须先执行选项8，设置AdminPassword以及RCONEnabled参数后才可以有效执行这个选项!!!)"
    echo "5. 从手动备份文件中恢复服务器存档(文件名manualbackup.zip)"
    echo "6. 从自动备份文件中恢复服务器存档"
    echo "7. 卸载自动维护系统"
    echo "8. 查看游戏服务器实时日志"
    echo "9. 修改游戏规则文件"
    echo "10. 启动幻兽帕鲁Docker镜像"
    echo "11. 停止幻兽帕鲁Docker镜像"
    echo "12. 重启幻兽帕鲁Docker镜像"
    echo "13. RCON远程发送服务器指令"
    echo "14. 退出脚本"
    echo "请输入你的选项:"
}

# 选项1 - 安装Docker
install_docker() {
    # 安装 Docker
    apt-get update
    apt-get install -y ca-certificates curl gnupg lsb-release zip
    mkdir -p /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/debian/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian \
      $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
    apt-get update
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
    systemctl start docker
    systemctl enable docker
    echo "Docker组件已成功安装。"
}

# 选项2 - 部署新的Palworld服务器
deploy_palworld_server() {
    docker volume create palworld_saved
    docker pull kagurazakanyaa/palworld
    docker run -d --restart=always -e "ENABLE_MULTITHREAD=true" --name=palworld-server -v "palworld_saved:/opt/palworld/Pal/Saved" -p 8211:8211/udp -p 25575:25575 kagurazakanyaa/palworld
    echo "幻兽帕鲁服务器已部署完成。"
}

# 选项3 - 部署自动维护系统
deploy_auto_maintenance() {
    echo "请输入RCON密码(用于自动维护系统)"
    read -r MCRCON_PWD

    apt update && apt install zip -y

    # 创建备份脚本
    cat <<EOF > "$SCRIPT_DIR/backup_script.sh"
#!/bin/bash
$MCRCON_PATH -p $MCRCON_PWD "save"
sleep 20
zip -r "${BACKUP_STORE}/backup-\$(date +\%Y-\%m-\%d-\%H%M).zip" "$BACKUP_DIR"
$MCRCON_PATH -p $MCRCON_PWD "Broadcast ServerBackupCompleted"
# 如果备份文件夹容量超过了1GB，将会自动删除此文件夹下最早的备份存档文件。
total_size=\$(du -c "$BACKUP_STORE" | grep total\$ | awk '{print \$1}')
if [ \$total_size -ge 1048576 ]; then
    oldest_backup=\$(ls -t "$BACKUP_STORE" | tail -1)
    rm -f "$BACKUP_STORE/\$oldest_backup"
    $MCRCON_PATH -p $MCRCON_PWD "Broadcast Oldest backup deleted to free space"
fi
EOF
    chmod +x "$SCRIPT_DIR/backup_script.sh"

    # 立即执行一次备份
    "$SCRIPT_DIR/backup_script.sh"

    # 创建重启脚本
    cat <<EOF > "$SCRIPT_DIR/restart_script.sh"
#!/bin/bash
$MCRCON_PATH -p $MCRCON_PWD "Broadcast ServerWillBeRestartIn5Mins"
sleep 300
docker restart palworld-server
EOF

    # 创建自动检查更新脚本
    cat <<EOF > "$SCRIPT_DIR/update_check_script.sh"
#!/bin/bash
# 检查是否有可用更新
if docker pull kagurazakanyaa/palworld | grep -q 'Downloaded newer image'; then
    $MCRCON_PATH -p $MCRCON_PWD "Broadcast ServerWillBeRestartIn5Mins"
    sleep 300
    docker restart palworld-server
fi
EOF
    chmod +x "$SCRIPT_DIR/update_check_script.sh"

    # 设置 cron 任务
    (crontab -l 2>/dev/null; echo "0 */$BACKUP_FREQUENCY * * * $SCRIPT_DIR/backup_script.sh") | crontab -
    (crontab -l 2>/dev/null; echo "5 */$RESTART_FREQUENCY * * * $SCRIPT_DIR/restart_script.sh") | crontab -
    (crontab -l 2>/dev/null; echo "*/30 * * * * $SCRIPT_DIR/update_check_script.sh") | crontab -
    echo "自动维护系统部署成功。"
}

# 选项4 - 创建手动备份
create_backup() {
    echo "请输入RCON密码(用于创建手动备份)"
    read -r MCRCON_PWD
    echo "正在创建手动备份。"
    $MCRCON_PATH -p $MCRCON_PWD "save"
    sleep 20
    apt update && apt install zip -y
    local backup_file="$SCRIPT_DIR/manualbackup.zip"
    zip -r "$backup_file" "$BACKUP_DIR"
    $MCRCON_PATH -p $MCRCON_PWD "Broadcast ServerBackupCompleted"
    echo "手动备份文件已经保存在了 $backup_file。"
}

# 选项5 - 从备份文件复制备份
copy_backup_from_folder() {
    echo "正在从备份文件恢复存档..."
    docker stop palworld-server
    sleep 20
    apt update && apt install zip -y
    local backup_file="$SCRIPT_DIR/scriptbackup.zip"
    unzip -o "$backup_file" -d "$BACKUP_DIR"
    docker start palworld-server
    echo "存档已从$backup_file 恢复成功。"
}

# 选项6 - 从自动备份系统复制备份
copy_backup_from_auto_system() {
    echo "正在从自动备份文件恢复存档..."
    docker stop palworld-server
    sleep 20
    apt update && apt install zip -y
    echo "以下是有效的自动备份存档"
    ls "$BACKUP_STORE"
    echo "请输入一个你想要恢复的自动备份存档文件名并回车："
    read -r backup_file
    unzip -o "$BACKUP_STORE$backup_file" -d "$BACKUP_DIR"
    docker start palworld-server
    echo "存档文件 $backup_file 恢复完成。"
}

# 选项7 - 卸载自动维护系统
purge_auto_maintenance() {
    crontab -l | grep -v "$SCRIPT_DIR/backup_script.sh" | crontab -
    crontab -l | grep -v "$SCRIPT_DIR/restart_script.sh" | crontab -
    echo "自动维护系统已卸载。"
}

# 选项8 - 检查实时日志
view_real_time_logs() {
    sudo docker logs palworld-server -f --tail=100
}

# 选项9 - 修改游戏规则文件
edit_game_rules_file() {
    sudo nano /var/lib/docker/volumes/palworld_saved/_data/Config/LinuxServer/PalWorldSettings.ini
}

# 选项10 - 启动帕鲁服务器
start_game_docker_image() {
    sudo docker start palworld-server
}

# 选项11 - 关闭帕鲁服务器
stop_game_docker_image() {
    sudo docker stop palworld-server
}

# 选项12 - 重启帕鲁服务器
restart_game_docker_image() {
    sudo docker restart palworld-server
}

# 选项13 - 远程RCON服务器指令
rcon_broadcast_message() {
    if [ -z "$MCRCON_PWD" ]; then
        echo "请输入RCON密码:"
        read -r MCRCON_PWD
    fi

    echo "请输入你想要发送的指令:"
    read -r command
    $MCRCON_PATH -p "$MCRCON_PWD" "$command"
}

# 主循环
while true; do
    show_menu
    read -r choice
    case $choice in
        1) install_docker ;;
        2) deploy_palworld_server ;;
        3) deploy_auto_maintenance ;;
        4) create_backup ;;
        5) copy_backup_from_folder ;;
        6) copy_backup_from_auto_system ;;
        7) purge_auto_maintenance ;;
        8) view_real_time_logs ;;
        9) edit_game_rules_file ;;
        10) start_game_docker_image ;;
        11) stop_game_docker_image ;;
        12) restart_game_docker_image ;;
        13) rcon_broadcast_message ;;
        14) exit 0 ;;
        *) echo "这是错误的选择，请重新输入：" ;;
    esac
done
